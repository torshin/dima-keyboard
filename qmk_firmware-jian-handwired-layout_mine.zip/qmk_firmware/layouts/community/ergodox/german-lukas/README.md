# About this keymap

This keymap is based on the qwertz layout.
It has a key for pressing the left control and the left alt key at once.

Linux makes a difference between AltGr and Control + Alt. Some keybindings are easier to press now.

Also, I added a layer for pressing Control + Alt + F-Keys very fast.

# Layer

Each layer in the *keymap.c*-file has a comment showing the mappings of the layer.
